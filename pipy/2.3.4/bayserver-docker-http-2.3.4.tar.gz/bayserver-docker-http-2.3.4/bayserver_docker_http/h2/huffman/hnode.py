
class HNode:

    def __init__(self):
        self.value = -1
        self.one = None
        self.zero = None