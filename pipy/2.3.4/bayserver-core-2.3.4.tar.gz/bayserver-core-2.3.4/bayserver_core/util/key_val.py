class KeyVal:
    def __init__(self, name, val):
        self.name = name
        self.value = val
