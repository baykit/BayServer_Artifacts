from bayserver_core.docker.docker import Docker

class Log(Docker):
    pass