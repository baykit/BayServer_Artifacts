from bayserver_core.docker.docker import Docker

class City(Docker):
    pass
    #
    # interface
    #
    #     String name();
    #     List<Club> clubs();
    #     List<Town> towns();
    #     void enter(Tour tour) throws HttpException;
    #     Trouble getTrouble();
    #     void log(Tour tour);
    #