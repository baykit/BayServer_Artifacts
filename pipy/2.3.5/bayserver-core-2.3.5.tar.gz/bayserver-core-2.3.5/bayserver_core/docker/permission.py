from bayserver_core.docker.docker import Docker

class Permission(Docker):
    pass